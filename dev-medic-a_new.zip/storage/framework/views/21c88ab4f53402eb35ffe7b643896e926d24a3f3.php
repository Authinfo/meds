<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.booking.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.bookings.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.booking.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($booking->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.booking.fields.nomor_order')); ?>

                        </th>
                        <td>
                            <?php echo e($booking->nomor_order); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.booking.fields.tanggal_permintaan')); ?>

                        </th>
                        <td>
                            <?php echo e($booking->tanggal_permintaan); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.booking.fields.status_booking')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Booking::STATUS_BOOKING_RADIO[$booking->status_booking] ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.booking.fields.user_name')); ?>

                        </th>
                        <td>
                            <?php $__currentLoopData = $booking->user_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="label label-info"><?php echo e($user_name->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.booking.fields.category')); ?>

                        </th>
                        <td>
                            <?php $__currentLoopData = $booking->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="label label-info"><?php echo e($category->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.booking.fields.product_name')); ?>

                        </th>
                        <td>
                            <?php $__currentLoopData = $booking->product_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="label label-info"><?php echo e($product_name->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.booking.fields.jenis_booking')); ?>

                        </th>
                        <td>
                            <?php echo e($booking->jenis_booking); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.booking.fields.nama_orang_lain')); ?>

                        </th>
                        <td>
                            <?php echo e($booking->nama_orang_lain); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.booking.fields.email_orang_lain')); ?>

                        </th>
                        <td>
                            <?php echo e($booking->email_orang_lain); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.booking.fields.nomor_identitas_orang_lain')); ?>

                        </th>
                        <td>
                            <?php echo e($booking->nomor_identitas_orang_lain); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.booking.fields.dob_orang_lain')); ?>

                        </th>
                        <td>
                            <?php echo e($booking->dob_orang_lain); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.bookings.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_7.3.28\htdocs\data_saya\dev-medic-a\resources\views/admin/bookings/show.blade.php ENDPATH**/ ?>