<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card">
                <div class="card-header">
                    Booking Baru
                </div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route("frontend.bookings.store")); ?>" enctype="multipart/form-data">
                        <?php echo method_field('POST'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label class="required" for="tanggal_permintaan"><?php echo e(trans('cruds.booking.fields.tanggal_permintaan')); ?></label>
                            <input class="form-control date" type="text" name="tanggal_permintaan" id="tanggal_permintaan" value="<?php echo e(old('tanggal_permintaan')); ?>" required>
                            <?php if($errors->has('tanggal_permintaan')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('tanggal_permintaan')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.booking.fields.tanggal_permintaan_helper')); ?></span>
                        </div>

                        <div class="form-group">
                            <label for="categories">Kategori</label>
                            <?php $__currentLoopData = App\Models\ProductCategory::PRODUCT_CATEGORIES_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <input type="radio" id="product_categories_<?php echo e($key); ?>" name="categories" value="<?php echo e($key); ?>" <?php echo e(old('categories', '') === (string) $key ? 'checked' : ''); ?>>
                                    <label for="product_categories_<?php echo e($key); ?>"><?php echo e($label); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($errors->has('categories')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('categories')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.booking.fields.category_helper')); ?></span>
                        </div>

                        <div class="form-group">
                            <label><?php echo e(trans('cruds.booking.fields.product_name')); ?></label>
                            <?php $__currentLoopData = App\Models\Product::PRODUCTS_NAME_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <input type="radio" id="product_name_<?php echo e($key); ?>" name="product_name" value="<?php echo e($key); ?>" <?php echo e(old('product_name', '') === (string) $key ? 'checked' : ''); ?>>
                                    <label for="product_name_<?php echo e($key); ?>"><?php echo e($label); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($errors->has('product_name')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('product_name')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.booking.fields.product_name_helper')); ?></span>
                        </div>

                        <div class="form-group">
                            <label><?php echo e(trans('cruds.booking.fields.jenis_booking')); ?></label>
                            <?php $__currentLoopData = App\Models\Booking::JENIS_BOOKING_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <input type="radio" id="jenis_booking<?php echo e($key); ?>" name="jenis_booking" value="<?php echo e($key); ?>" <?php echo e(old('jenis_booking', '') === (string) $key ? 'checked' : ''); ?>>
                                    <label for="jenis_booking_<?php echo e($key); ?>"><?php echo e($label); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($errors->has('jenis_booking')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('jenis_booking')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.booking.fields.jenis_booking_helper')); ?></span>
                        </div>

                        <div class="form-group">
                            <label for="nama_orang_lain"><?php echo e(trans('cruds.booking.fields.nama_orang_lain')); ?></label>
                            <input class="form-control" type="text" name="nama_orang_lain" id="nama_orang_lain" value="<?php echo e(old('nama_orang_lain', '')); ?>">
                            <?php if($errors->has('nama_orang_lain')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('nama_orang_lain')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.booking.fields.nama_orang_lain_helper')); ?></span>
                        </div>

                        <div class="form-group">
                            <label for="email_orang_lain"><?php echo e(trans('cruds.booking.fields.email_orang_lain')); ?></label>
                            <input class="form-control" type="email" name="email_orang_lain" id="email_orang_lain" value="<?php echo e(old('email_orang_lain')); ?>">
                            <?php if($errors->has('email_orang_lain')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('email_orang_lain')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.booking.fields.email_orang_lain_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label for="nomor_identitas_orang_lain"><?php echo e(trans('cruds.booking.fields.nomor_identitas_orang_lain')); ?></label>
                            <input class="form-control" type="text" name="nomor_identitas_orang_lain" id="nomor_identitas_orang_lain" value="<?php echo e(old('nomor_identitas_orang_lain', '')); ?>">
                            <?php if($errors->has('nomor_identitas_orang_lain')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('nomor_identitas_orang_lain')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.booking.fields.nomor_identitas_orang_lain_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label for="dob_orang_lain"><?php echo e(trans('cruds.booking.fields.dob_orang_lain')); ?></label>
                            <input class="form-control date" type="text" name="dob_orang_lain" id="dob_orang_lain" value="<?php echo e(old('dob_orang_lain')); ?>">
                            <?php if($errors->has('dob_orang_lain')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('dob_orang_lain')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.booking.fields.dob_orang_lain_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-danger" type="submit">
                                <?php echo e(trans('global.save')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Penta\Documents\noplt\dev-medic-a\resources\views/frontend/bookings/create.blade.php ENDPATH**/ ?>