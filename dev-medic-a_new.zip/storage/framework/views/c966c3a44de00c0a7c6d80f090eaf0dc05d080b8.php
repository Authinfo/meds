<?php echo e($slot); ?>

<?php /**PATH C:\key\New folder\dev-medic-a_new\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>