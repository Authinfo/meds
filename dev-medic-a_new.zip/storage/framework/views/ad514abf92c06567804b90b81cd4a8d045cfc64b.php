<?php $__env->startSection('content'); ?>

<div class="row justify-content-center">
    <div class="col-md-6">

        <div class="card mx-4">
            <div class="card-body p-4">

                <form method="POST" action="<?php echo e(route('register')); ?>">
                    <?php echo e(csrf_field()); ?>


                    <h1><?php echo e(trans('panel.site_title')); ?></h1>
                    Sudah Punya Account?<p class="text-muted"><a href="<?php echo e(route('login')); ?>"><?php echo e(trans('global.login')); ?></a></p>

                    <label for="name"> Nama Lengkap</label>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fa fa-user fa-fw"></i>
                            </span>
                        </div>
                        <input type="text" name="name" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" required autofocus placeholder="<?php echo e(trans('global.user_name')); ?>" value="<?php echo e(old('name', null)); ?>">
                        <?php if($errors->has('name')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('name')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <label for="email">Alamat Email</label>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fa fa-envelope fa-fw"></i>
                            </span>
                        </div>
                        <input type="email" name="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" required placeholder="<?php echo e(trans('global.login_email')); ?>" value="<?php echo e(old('email', null)); ?>">
                        <?php if($errors->has('email')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('email')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <label for="number">Nomor Handphone</label>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fa fa-phone fa-fw"></i>
                            </span>
                        </div>
                        <input type="number" name="number" class="form-control<?php echo e($errors->has('number') ? ' is-invalid' : ''); ?>" required placeholder="<?php echo e(trans('global.phone')); ?>" value="<?php echo e(old('number', null)); ?>">
                        <?php if($errors->has('number')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('number')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <label for="idtype">Jenis Identitas</label>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fa fa-genderless fa-fw"></i>
                            </span>
                        </div>
                        <select class="form-control <?php echo e($errors->has('idtype') ? 'is-invalid' : ''); ?>" name="idtype" id="idtype" required>
                            <option value disabled <?php echo e(old('idtype', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                            <?php $__currentLoopData = App\Models\User::IDTYPE_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>" <?php echo e(old('idtype', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('idtype')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('idtype')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <label for="noid">Nomor Identitas</label>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fa fa-id-card fa-fw"></i>
                            </span>
                        </div>
                        <input type="text" name="noid" class="form-control<?php echo e($errors->has('noid') ? ' is-invalid' : ''); ?>" required autofocus placeholder="Nomor Identitas" value="<?php echo e(old('noid', null)); ?>">
                        <?php if($errors->has('noid')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('noid')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <label for="alamat">Alamat Sesuai Identitas</label>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fa fa-location-arrow fa-fw"></i>
                            </span>
                        </div>
                        <input type="text" name="alamat" class="form-control<?php echo e($errors->has('alamat') ? ' is-invalid' : ''); ?>" required autofocus placeholder="Alamat" value="<?php echo e(old('alamat', null)); ?>">
                        <?php if($errors->has('alamat')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('alamat')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <label for="dob">Tanggal Lahir</label>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fa fa-calendar fa-fw"></i>
                            </span>
                        </div>
                        <input type="text" class="form-control date <?php echo e($errors->has('dob') ? 'is-invalid' : ''); ?>" name="dob" id="dob" placeholder="D-M-Y // 12-09-1999" value="<?php echo e(old('dob')); ?>" required>
                        <?php if($errors->has('dob')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('dob')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <label for="jk">Jenis Kelamin</label>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fa fa-user fa-fw"></i>
                            </span>
                        </div>
                        <select class="form-control <?php echo e($errors->has('jk') ? 'is-invalid' : ''); ?>" name="jk" id="jk" required>
                            <option value disabled <?php echo e(old('jk', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                            <?php $__currentLoopData = App\Models\User::JK_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>" <?php echo e(old('jk', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('jk')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('jk')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <label for="password">Kata Sandi</label>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fa fa-lock fa-fw"></i>
                            </span>
                        </div>
                        <input type="password" name="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" required placeholder="<?php echo e(trans('global.login_password')); ?>">
                        <?php if($errors->has('password')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('password')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <label for="password_confirmation">Konfirmasi Kata Sandi</label>
                    <div class="input-group mb-4">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="fa fa-lock fa-fw"></i>
                            </span>
                        </div>
                        <input type="password" name="password_confirmation" class="form-control" required placeholder="<?php echo e(trans('global.login_password_confirmation')); ?>">
                    </div>

                    <button class="btn btn-block btn-primary">
                        <?php echo e(trans('global.register')); ?>

                    </button>
                </form>

            </div>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Penta\Documents\noplt\dev-medic-a\resources\views/auth/register.blade.php ENDPATH**/ ?>