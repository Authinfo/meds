[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\key\New folder\dev-medic-a_new\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>