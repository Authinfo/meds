
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card">
                <div class="card-header">
                    Pembayaran
                </div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(url("frontend/post_payment")); ?>">
                        <?php echo method_field('POST'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                                <div style="text-align: center">Anda telah melakukan booking hari ini <br> silahkan tentukan pilihan pembayaran dibawah ini :</div>                            
                                <input class="form-control" type="hidden" name="nomor_order" value="<?php echo e($data->nomor_order); ?>"/>                                                                                                                    
                            </div>
                        
                        <div class="form-group" style="text-align: center">
                            <button class="btn btn-primary" type="submit">
                                Bayar Di Tempat
                            </button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_7.3.28\htdocs\data_saya\dev-medic-a\resources\views/frontend/bookings/payment.blade.php ENDPATH**/ ?>