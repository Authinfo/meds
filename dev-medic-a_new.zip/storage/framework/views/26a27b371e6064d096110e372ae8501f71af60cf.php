<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.booking.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.bookings.update", [$booking->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="nomor_order"><?php echo e(trans('cruds.booking.fields.nomor_order')); ?></label>
                <input class="form-control <?php echo e($errors->has('nomor_order') ? 'is-invalid' : ''); ?>" type="text" name="nomor_order" id="nomor_order" value="<?php echo e(old('nomor_order', $booking->nomor_order)); ?>" required>
                <?php if($errors->has('nomor_order')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('nomor_order')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booking.fields.nomor_order_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="tanggal_permintaan"><?php echo e(trans('cruds.booking.fields.tanggal_permintaan')); ?></label>
                <input class="form-control date <?php echo e($errors->has('tanggal_permintaan') ? 'is-invalid' : ''); ?>" type="text" name="tanggal_permintaan" id="tanggal_permintaan" value="<?php echo e(old('tanggal_permintaan', $booking->tanggal_permintaan)); ?>" required>
                <?php if($errors->has('tanggal_permintaan')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('tanggal_permintaan')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booking.fields.tanggal_permintaan_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.booking.fields.status_booking')); ?></label>
                <?php $__currentLoopData = App\Models\Booking::STATUS_BOOKING_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check <?php echo e($errors->has('status_booking') ? 'is-invalid' : ''); ?>">
                        <input class="form-check-input" type="radio" id="status_booking_<?php echo e($key); ?>" name="status_booking" value="<?php echo e($key); ?>" <?php echo e(old('status_booking', $booking->status_booking) === (string) $key ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="status_booking_<?php echo e($key); ?>"><?php echo e($label); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($errors->has('status_booking')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('status_booking')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booking.fields.status_booking_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="user_names"><?php echo e(trans('cruds.booking.fields.user_name')); ?></label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0"><?php echo e(trans('global.deselect_all')); ?></span>
                </div>
                <select class="form-control select2 <?php echo e($errors->has('user_names') ? 'is-invalid' : ''); ?>" name="user_names[]" id="user_names" multiple required>
                    <?php $__currentLoopData = $user_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $user_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((in_array($id, old('user_names', [])) || $booking->user_names->contains($id)) ? 'selected' : ''); ?>><?php echo e($user_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('user_names')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('user_names')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booking.fields.user_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="categories"><?php echo e(trans('cruds.booking.fields.category')); ?></label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0"><?php echo e(trans('global.deselect_all')); ?></span>
                </div>
                <select class="form-control select2 <?php echo e($errors->has('categories') ? 'is-invalid' : ''); ?>" name="categories[]" id="categories" multiple>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((in_array($id, old('categories', [])) || $booking->categories->contains($id)) ? 'selected' : ''); ?>><?php echo e($category); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('categories')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('categories')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booking.fields.category_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="product_names"><?php echo e(trans('cruds.booking.fields.product_name')); ?></label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0"><?php echo e(trans('global.deselect_all')); ?></span>
                </div>
                <select class="form-control select2 <?php echo e($errors->has('product_names') ? 'is-invalid' : ''); ?>" name="product_names[]" id="product_names" multiple required>
                    <?php $__currentLoopData = $product_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $product_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((in_array($id, old('product_names', [])) || $booking->product_names->contains($id)) ? 'selected' : ''); ?>><?php echo e($product_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('product_names')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('product_names')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booking.fields.product_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="jenis_booking"><?php echo e(trans('cruds.booking.fields.jenis_booking')); ?></label>
                <input class="form-control <?php echo e($errors->has('jenis_booking') ? 'is-invalid' : ''); ?>" type="text" name="jenis_booking" id="jenis_booking" value="<?php echo e(old('jenis_booking', $booking->jenis_booking)); ?>" required>
                <?php if($errors->has('jenis_booking')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('jenis_booking')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booking.fields.jenis_booking_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\cans\dev-medic-a_new\resources\views/admin/bookings/edit.blade.php ENDPATH**/ ?>