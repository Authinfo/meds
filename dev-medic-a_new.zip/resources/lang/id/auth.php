<?php

return [
    'failed'   => 'ID pengguna atau password salah',
    'password' => 'Password yang anda masukkan salah',
    'throttle' => 'Terlalu banyak percubaan log masuk.  Sila cuba semula dalam :seconds saat.',
];
