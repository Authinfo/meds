<?php

return [
    'site_title' => 'Medic-a Clinic',
];
