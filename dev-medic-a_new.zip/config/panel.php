<?php

return [
    'date_format'         => 'd-m-Y',
    'time_format'         => 'H:i:s',
    'primary_language'    => 'id',
    'available_languages' => [
        'id' => 'Bahasa / Indonesia',
    ],
    'registration_default_role' => '2',
];
